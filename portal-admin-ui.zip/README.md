# Portal Admin: sidebar baru, Akun (tab role), Dashboard "Perlu tindakan"

Salin folder `src/admin/` ke proyek React kamu.

Dependensi: `react`, `react-router-dom` (v6), `lucide-react`. Tidak ada library UI lain.

## 1. Pasang rute

```jsx
import './admin/admin.css';
import AdminLayout from './admin/components/AdminLayout';
import DashboardAdmin from './admin/pages/DashboardAdmin';
import ManajemenAkun from './admin/pages/ManajemenAkun';

<Route path="/admin" element={<AdminLayout me={me} onLogout={logout} />}>
  <Route index element={<DashboardAdmin nama={me.nama_lengkap}>{/* widget lama kamu */}</DashboardAdmin>} />
  <Route path="akun" element={<ManajemenAkun me={me} />} />
  <Route path="dokter" element={<HalamanDokterLama />} />
  <Route path="laporan" element={<LaporanLama />} />
  <Route path="audit-log" element={<AuditLogLama />} />
  <Route path="persetujuan-pdp" element={<PersetujuanPdpLama />} />
  <Route path="hero" element={<HeroLama />} />
</Route>
```

`me` harus punya `nama_lengkap` dan `tipe` (`admin` atau `superadmin`).
`tipe` menentukan siapa yang boleh menekan "Undang Admin" (hanya superadmin).

## 2. Sesuaikan ke backend: semua ada di `api.js`

| Hal | Asumsi saya | Cek |
|---|---|---|
| Token | `localStorage.token`, header Bearer | `getToken()` |
| Daftar | `GET /admin/pengguna?role&status&q&page` -> `{ data: [...], meta }` | respons |
| Field baris | `id, nama_lengkap, tipe, status, no_telepon, email, last_login_at, telepon_terverifikasi` | `ManajemenAkun.jsx` |
| Ringkasan | `data.per_role`, `data.per_status` | `getRingkasan()` |
| Tolak | body `{ alasan }` | `tolak()` |
| Undangan | body `{ tipe, nama_lengkap, no_telepon, email, kanal }` | `BuatUndanganRequest` |
| Id undangan di baris | `u.undangan_id` atau `u.undangan.id` | `aksiUntuk()` |
| Nonaktifkan / reset sandi | `PUT .../status`, `POST .../reset-sandi` | pakai route halaman lama |
| Dokter menunggu | `GET /admin/dokter?status_verifikasi=pending` -> `meta.total` | `getPerluTindakan()` |

Kalau nama field berbeda, ubah di `ManajemenAkun.jsx` (cari `u.`) atau di normalizer `api.js`.

## 3. Yang berubah dari tampilan lama

- Sidebar: 13 item -> 7 item. Role akun jadi tab di halaman Akun, bukan menu.
- Satu baris tab role (dengan angka), lalu satu baris cari + dropdown status.
- Tab dan filter tersimpan di URL: `/admin/akun?role=marketing&status=menunggu_persetujuan`.
- Aksi baris mengikuti status: Setujui/Tolak, Kirim ulang/Batalkan, Reset sandi/Nonaktifkan, Aktifkan.
- Tolak wajib alasan. Semua aksi berisiko memakai dialog konfirmasi.
- Tombol "Undang" hanya muncul di tab Dokter, Apoteker, Kurir (dan Admin untuk superadmin).
- Dashboard: kartu "Perlu tindakan" paling atas. Banner sambutan dan emoji dihapus.
- Bar atas tidak lagi mengulang "Portal Admin".

## 4. Belum dikerjakan

- Halaman Laporan: ubah default periode dari "Hari ini" ke 30 hari terakhir.
- Audit log: petakan `users #11` dan `diubah_at` ke kalimat manusia.
- Halaman Hero: hapus teks "GET/POST/PUT/DELETE" dan "Eloquent" dari deskripsi.
- Aksi massal (checkbox di halaman Dokter) belum punya tombol aksi.
- Halaman aktivasi undangan dan daftar Marketing (halaman publik) belum dibuat.
